#include <stdio.h>

int main(){
int a=0;
printf("hello,world!\a\n");
system("Pause");

return 0;
}
